
       var el = document.getElementsByClassName('frm1');
       
       el.addEventListener('submit', function(){
       return;
       }, false);
    function toggleField(hideObj,showObj){
       hideObj.disabled=true;        
       hideObj.style.display='none';
       showObj.disabled=false;   
       showObj.style.display='inline';
       showObj.focus();
     }

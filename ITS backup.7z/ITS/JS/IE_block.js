
function isIE() {
  var userAgent = navigator.userAgent;
  return /MSIE|Trident/.test(userAgent);
}
 
if (isIE()) {
        alert("Radi boljeg korisničkog iskustva, molimo Vas da koristite GOOGLE CHROME internet pretraživač.");
    }


<div class="container animate-bottom" id="container">
    <?php echo $_SESSION['newTicInfo']; ?>
</div>
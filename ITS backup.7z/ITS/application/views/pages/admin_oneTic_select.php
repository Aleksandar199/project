<?php
require_once "db_conn.php";
session_start();
error_reporting(0);

if(empty($_SESSION['logged_in']))
{
    header('Location: /ITS/admin_logIn');
    exit;
}


//SELECT TICKET INFO
$tic_ID = $_GET['ticID'];
$sql = "SELECT * FROM tickets WHERE tic_number='$tic_ID'";
$result = mysqli_query($conn, $sql);

while($res =  mysqli_fetch_assoc($result)){
    $ime = $res['name'];
    $prezime = $res['surname'];
    $email = $res['email'];
    $lokacija = $res['location'];
    $departman = $res['department'];
    $date_cr = $res['date_created'];
    $tip_tiketa = $res['type_tic'];
    $tip_problema = $res['type_problem'];
    $opis_problema = $res['description'];
    $status = $res['status'];
    $br_tic = $res['tic_number'];
    $reklama_opis =  $res['reklamacija_comment'];
    $date_reklama =  $res['date_reklama'];
    $IT_tech_ID =  $res['IT_tech_ID'];
    $date_accepted =  $res['date_accepted_tic'];
    $date_closed =  $res['date_closed_tic'];
    $desc_solution =  $res['desc_solution'];
}

$sql2 = "SELECT * FROM users WHERE id='$IT_tech_ID'";
  $result2 = mysqli_query($conn, $sql2);

  while($res2 =  mysqli_fetch_assoc($result2)){
    $ITime = $res2['name'];
    $ITprezime = $res2['surname'];
  }

//CONFIRM TICKET (OPEN)
if(isset($_POST['btn_open'])){
    $user_id = $_SESSION['user_id'];
    $date = date('d-m-Y H:i:s');

    $sql= "UPDATE tickets SET status='OTVOREN', IT_tech_ID='$user_id', date_accepted_tic='$date' WHERE tic_number='$tic_ID'";
    $result2 = mysqli_query($conn, $sql);
    echo "<script>
    swal({
      title: 'Ticketing System',
      text: '".$_SESSION['ime'].", uspešno ste preuzeli tiket broj $br_tic.',
      icon: 'success',
      button: 'OK',
    })
    .then((value) => {
      location='admin_oneTic_select?ticID=$br_tic';
    });
    </script>";
}

  //COMMENT TICKET
if(isset($_POST['btn_comment'])){

  $date_comment = date('d-m-Y H:i:s');
  $komentar =  $desc_solution."\n|--------------------------------------| $date_comment\n".$_POST['IT_comment'];
  $sql= "UPDATE tickets SET desc_solution='$komentar'  WHERE tic_number='$tic_ID'";
  $result = mysqli_query($conn, $sql);
  echo "<script>
  swal({
    title: 'Ticketing System',
    text: 'Uspešno ste postavili svoj komentar.',
    icon: 'success',
    button: 'OK',
  })
  .then((value) => {
    location='admin_oneTic_select?ticID=$br_tic';
  });
  </script>";
}

//CONFIRM TO CLOSE TICKET (CLOSE)
if(isset($_POST['btn_close'])){

  $date_closed = date('d-m-Y H:i:s');
  $sql= "UPDATE tickets SET status='ZATVOREN', date_closed_tic='$date_closed' WHERE tic_number='$tic_ID'";
  $result = mysqli_query($conn, $sql);
  echo "<script>
  swal({
    title: 'Ticketing System',
    text: '".$_SESSION['ime'].", ušpesno ste zatvorili tiket broj $br_tic.',
    icon: 'success',
    button: 'OK',
  })
  .then((value) => {
    location='admin_oneTic_select?ticID=$br_tic';
  });
  </script>";
}

 //VERIFY IF ID USER MATCH
               
 $userID = $_SESSION['user_id'];
 $query = "SELECT * FROM tickets WHERE tic_number='$br_tic' AND IT_tech_ID='$userID'";
 $result3 = mysqli_query($conn, $query);
 
 //SELECT ALL IT TECH, BUT NOT LOGGED IN USER
 $query2 = "SELECT * FROM tits.users WHERE NOT id='$userID'";
 $result4 = mysqli_query($conn, $query2);

 //IT TECH CHANGE
 $uid = $_POST['user'];
 if(isset($_POST['btn_change_tech'])){

  $query3 = "UPDATE tits.tickets SET IT_tech_ID='$uid' WHERE tic_number='$br_tic'";
  $result5 = mysqli_query($conn, $query3);
  echo "<script>
  swal({
    title: 'Ticketing System',
    text: 'Ušpesno ste prosledili tiket broj $br_tic odabranom IT tehničaru.',
    icon: 'success',
    button: 'OK',
  })
  .then((value) => {
    location='admin_oneTic_select?ticID=$br_tic';
  });
  </script>";
 }

?>
<div class="container animate-bottom" id="container"> 
<h2 class="text-center">TIKET ID: <span class="text-warning"><?php echo $_GET['ticID']; ?></span></h2>
<button onclick="goBack()" class="btn btn-primary button-back float-left btn-main"><i class="bi bi-arrow-left-square"></i> Nazad</button><br><br>
<div class="row">
    <div class="col-lg-6">
      <table class="table table-sm table-dark table-tic">
         <tbody>
          <tr>
            <th class="table-tic-th">Ime: <?php echo "<span class='text-success'>".$ime."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Prezime: <?php echo "<span class='text-success'>".$prezime."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">E-mail: <?php echo "<span class='text-success'>".$email."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Lokacija: <?php echo "<span class='text-success'>".$lokacija."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Tip tiketa: <?php echo "<span class='text-success'>".$tip_tiketa."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Departman: <?php echo "<span class='text-success'>".$departman."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Status: <?php echo "<span class='text-success'>".$status."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Tip problema: <?php echo "<span class='text-success'>".$tip_problema."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Opis problema: <?php echo "<span class='text-success'>".$opis_problema."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Datum kreiranja: <?php echo "<span class='text-success'>".$date_cr."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Datum preuzimanja: <?php echo "<span class='text-success'>".$date_accepted."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Datum zatvaranja: <?php echo "<span class='text-success'>".$date_closed."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Datum reklamacije: <?php echo "<span class='text-success'>".$date_reklama."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">IT tehničar: <?php echo "<span class='text-success'>".$ITime. " ".$ITprezime."</span>" ?></th>
          </tr>
          <tr>
            <th  class="table-tic-th">Komentar reklamacije: <?php echo "<span class='text-success'>".$reklama_opis."</span>" ?></th>
          </tr>
        </tbody>
      </table>
   </div>
   <div class="col-lg-6">
         <div class="card card-comm-it bg-dark">
         <h4 class="text-center text-white">IT tehničar <?php echo "<span class='text-success'>".$_SESSION['ime']. " ".$_SESSION['prezime']."</span>" ?></h4>
             <?php if($status == "NOV"):?>
               <form class="frm1" action="" method="POST" onsubmit="return confirm('Da li želite da preuzmete ovaj tiket? \nPotvrdom na dugme OK prihvatate tiket na Vaše ime i status ovog tiketa će se voditi kao OTVOREN tiket.');">
                  <label class="text-white">Ime i prezime podnosioca tiketa:</label>
                    <input type="text" class="form-control border-success" value="<?php echo $ime." ".$prezime;?>" disabled>
                  <label class="text-white">Komentar korisnika:</label>
                    <textarea type="text" class="form-control border-success" name="user_comment" rows="4" disabled><?php echo $opis_problema; ?></textarea><br>
   
                     <button type="submit" name="btn_open" class="btn btn-primary form-control">Prihvati tiket</button>
               </form>
              <?php endif; ?>
              <?php if($res1 =  mysqli_fetch_array($result3) > 0): ?>
                 <?php if($status == "OTVOREN" OR $status == "REKLAMACIJA"):?>
                 <form class="frm1" action="" method="POST" onsubmit="return confirm('Da li želite da prosledite ovaj komentar?');">

                 <?php if(!empty($desc_solution)):?>
                  <label class="text-white">Prethodni komentari:</label>
                    <textarea type='text' class='form-control' rows='4' disabled><?php echo $desc_solution; ?></textarea><br>
                <?php endif; ?>
                 <label class="text-white">Komentar IT tehničara:</label>
                       <textarea type="text" class="form-control border-success" name="IT_comment" placeholder="Napišite Vaš komentar ovde.." rows="4" style="border-radius: 5px 5px 0 0"></textarea>
                    <button type="submit" name="btn_comment" class="btn btn-success form-control" style="border-radius: 0 0 5px 5px">Postavi komentar</button>
                 </form>
                 <?php endif; ?>
   
                 <?php if($status == "OTVOREN" OR $status == "REKLAMACIJA"): ?>
                   <form class="frm1" id="tic_form" action="" method="POST" onsubmit="return confirm('Da li želite da zatvorite ovaj tiket? \nPotvrdom na dugme OK prihvatate tiket na Vaše ime i status ovog tiketa će se voditi kao ZATVOREN tiket.');">
                     <p class="text-white">Napomena: Zatvaranjem tiketa se smatra da je tiket završen i više ne možete da dodajete komentar.</p>
                     <button type="submit" name="btn_close" class="btn btn-primary form-control">Zatvori tiket</button>
                  </form>
                  <form class="frm1" action="" method="POST" onsubmit="return confirm('Da li želite da prosledite Vaš tiket drugom IT tehničaru?');">
                    <div class="form-group">
                       <label class="text-white">Lista IT tehničara:</label>
                       <select class="form-control" id="sel1" name="user" required>
                         <?php 
                         while($row = mysqli_fetch_assoc($result4)){
                           echo "<option value='".$row['id']."'>".$row['name']." ".$row['surname']."</option>";
                        }
                         ?>
                       </select>
                    </div>
                     <button type="submit" name="btn_change_tech" class="btn btn-primary form-control">Prosledi tiket drugom tehničaru</button>
                  </form>
                 <?php endif; ?>
   
                 <?php if($status == "ZATVOREN"): ?>
                 <form class="frm1">
                    <label class="text-white">Ime i prezime podnosioca tiketa:</label>
                      <input type="text" class="form-control border-danger" value="<?php echo $ITime." ".$ITprezime;?>" disabled>
                    <label class="text-white">Komentari IT tehničara:</label>
                      <textarea type='text' class='form-control border-danger' rows='4' disabled><?php echo $desc_solution; ?></textarea><br>

                    <h4 class="text-danger text-center">Ovaj tiket je zatvoren.</h4>
                 </form>
                 <?php endif; ?>
              <?php else: ?>
                  <?php if($status == "OTVOREN" OR $status == "ZATVOREN" OR $status == "REKLAMACIJA"): ?>

                    <form class="frm1">
                    <label class="text-white">Ime i prezime podnosioca tiketa:</label>
                      <input type="text" class="form-control border-success" value="<?php echo $ime." ".$prezime;?>" disabled>
                    <label class="text-white">Komentar korisnika:</label>
                      <textarea type="text" class="form-control border-success" name="user_comment" rows="4" disabled><?php echo $opis_problema; ?></textarea><br>

                      <h4 class="text-danger text-center">Ovaj tiket je već preuzet od strane drugog tehničara.</h4>
                 </form>
                  <?php endif; ?>
              <?php endif; ?>
              </div>
         </div>
     </div>      
  </div>

<!-- COMFIRM FORM BEFORE INSENT IN DB-->
<script src="JS/comfirmBeforeInsertData.js"></script>
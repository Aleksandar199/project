<div class="container animate-bottom" id="container">
    <div class="card card-main bg-secondary border border-white text-white">
            <h4 class="text-center h3f"><i class="bi bi-info-circle"> UPUTSTVO I INFORMACIJE O TICKETING SISTEMU</i></h4>
            <div class="container">
               <p><b>- UPUTSTVO ZA KORISNIKE</b></p>
               <p>Na početnoj stranici postoji padajući meni sa 2 opcije: NOVI TIKET i REKLAMACIJA TIKETA. 
               <br><br>
               1. Ukoliko želite da napravite novi tiket izaberite opciju "NOVI TIKET" i 
               kliknite na dugme "Dalje". Nakon toga se otvara nov prozor gde ćete popuniti svoje podatke kao i opciju da li šaljete zahtev ili incident. Potvrdom na dugme "Pošalji" 
               tiket se prosleđuje u sistem sa statusom "novi" tiket. Kada IT tehničar preuzme Vaš tiket, status mu se menja u "OTVOREN".
               <br><br>
               2. Druga opcija u meniju je "REKLAMACIJA TIKETA". Klikom na tu opciju pojavljuje se polje za unos, gde treba da unesete broj/ID Vašeg tiketa. Ova opcija se koristi 
               samo u slučajevima ako je IT tehničar odradio Vaš tiket kao i ostavio komentar, a niste zadovoljni ili imate primenbu na isti. Reklamiranje nije moguće ako je tiket otvoren i tek u obradi.
               <br><br>
               <b>Pregled statusa tiketa</b>
               <br>
               Ukoliko želite da pogledate status Vašeg tiketa, da li je odradjen ili tek u obradi, unesite broj/ID Vašeg tiketa u predviđeno polje za unos na početnoj stranici, 
               zatim kliknite na dugme "Pretraži tiket".
               </p>
               <br><br>
               <i class="text-info">(Moguće kasnije izmene.)</i>
            </div>
    </div>



</div>
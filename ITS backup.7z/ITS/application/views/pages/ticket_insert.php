
<?php 
require_once "db_conn.php";
session_start();
error_reporting(0);

$ime = trim($_POST['name']);
$prezime = trim($_POST['surname']);
$email = trim($_POST['email']);
$departman = $_POST['dep'];
$lokacija = $_POST['location'];
$vrsta_tiketa = $_POST['type_tic'];
$tip_problema = $_POST['type_prob'];
$opis = trim($_POST['description']);
$status = $_SESSION['status'];

//count tickets
$sql = "SELECT count(*) FROM tits.tickets";
$result = mysqli_query($conn, $sql);
$res =  mysqli_fetch_array($result);
$tic_number = $res[0];
$tic_number = $tic_number + 1;
$num =  $res[0];
$num = $num + 1;


if($vrsta_tiketa == "INCIDENT"){
  $tic_number = "INC".$tic_number;  //INC100
}
else{
  $tic_number = "REQ".$tic_number;  //REQ100
}

$sql2 = "SELECT * FROM tickets WHERE tic_number LIKE '%$num'";
$result2 = mysqli_query($conn, $sql2);

if($res =  mysqli_fetch_array($result2) > 0){
  //count tickets
   $sql = "SELECT count(*) FROM tits.tickets";
   $result = mysqli_query($conn, $sql);
   $res =  mysqli_fetch_array($result);
   $tic_number = $res[0];
   $tic_number = $tic_number + 2;
  
   if($vrsta_tiketa == "INCIDENT"){
    $tic_number = "INC".$tic_number;  //INC100
  }
  else{
    $tic_number = "REQ".$tic_number;  //REQ100
  }

   //insert data in DB
   goto insert;
}
else{

  insert:
  //insert data in DB
  if(isset($_POST['btn_insert'])){
  
    if($ime == "" AND $prezime == "" AND $email == "" AND $opis == ""){
      echo " <script>
             swal({
              title: 'Ticketing System',
              text: 'Niste popunili sva polja!',
              icon: 'error',
              button: 'OK',
            });
            </script>";
            $msg = "<h4 class='text-danger text-center text-h4'>Niste popunili sva polja!</h4>";
    }
    else if(preg_match('/[^a-zA-Z ]/',$ime) OR preg_match('/[^a-zA-Z ]/',$prezime)){
      echo " <script>
             swal({
              title: 'Ticketing System',
              text: 'Ime i prezime mora da sadrži slova engleske abecede.',
              icon: 'error',
              button: 'OK',
            });
            </script>";
      $msg = "<h4 class='text-danger text-center text-h4'>Ime i prezime mora da sadrži slova engleske abecede.</h4>";
    }
    else if(strlen($ime) <= 3 OR strlen($prezime) <= 3){
      echo " <script>
             swal({
              title: 'Ticketing System',
              text: 'Ime ili prezime mora biti duže od 3 karaktera!',
              icon: 'error',
              button: 'OK',
            });
            </script>";
      $msg = "<h4 class='text-danger text-center text-h4'>Ime ili prezime mora biti duže od 3 karaktera!</h4>";
    }
    else{
       $_SESSION['newTicInfo'] = " 
       <div class='card bg-dark'>
          <h1 class='text-info text-center'>Vaš broj/ID tiketa je: $tic_number</h1>
          <h4 class='text-warning text-center'>Ime i prezime: $ime $prezime</h4>
          <h4 class='text-warning text-center'>E-mail: $email</h4>
          <h4 class='text-warning text-center'>Lokacija: $lokacija</h4>
          <h4 class='text-warning text-center'>Departman: $departman</h4>
          <h4 class='text-warning text-center'>Vrsta tiketa: $vrsta_tiketa</h4>
          <h4 class='text-warning text-center'>Tip problema: $tip_problema</h4>
          <h6 class='text-warning text-center'>Opis: $opis</h6>
        </div>
       ";

       $date = date('d-m-Y H:i:s');
       $query = "INSERT INTO tickets (`date_created`, `name`, `surname`, `email`, `location`, `department`, `type_tic`, `type_problem`, `description`, `status`, tic_number)  VALUES ('$date', '$ime', '$prezime', '$email', '$lokacija', '$departman', '$vrsta_tiketa', '$tip_problema', '$opis', '$status', '$tic_number')";
       
       $result = mysqli_query($conn, $query);
       mysqli_close($conn);
       
       echo "<script>
       swal({
        title: 'Ticketing System',
        text: 'Uspešno ste kreirali nov tiket.',
        icon: 'success',
        button: 'OK',
      })
      .then((value) => {
        location='newTicINFO';
      });
       </script>";
    }
  }
}

?>

<div class="container animate-bottom" id="container">
    <div class="card card-main bg-secondary text-white border border-white">
    <h3 class="text-center h3f">ITS TIKET</h3>
         <form class="frm1" action="/ITS/ticket_insert" method="POST" onsubmit="return confirm('Da li želite da pošaljete ovaj tiket? \nPotvrdite na OK dugme.');">
         <center><h5 class="h5-status">Status: otvarate  <?php echo $status; ?> TIKET</h5></center>
             <div class="form-group">
             <?php echo $msg; ?>
               <label>Ime:</label>
               <input type="text" name="name" class="form-control" placeholder="Unesite ime..">
             </div>
             <div class="form-group">
               <label>Prezime:</label>
               <input type="text" name="surname" class="form-control" placeholder="Unesite prezime..">
             </div>
             <div class="form-group">
               <label>Email:</label>
               <input type="email" name="email" class="form-control" placeholder="Unesite email.." id="txtHint" autocomplete="email">
             </div>
             <div class="form-group">
                 <label>Departman:</label>
                 <select class="form-control" id="sel1" name="dep" required>
                   <option value="RECEIVING">RECEIVING</option>
                   <option value="INCOMING">INCOMING</option>
                   <option value="LABORATORIJA">LABORATORIJA</option>
                   <option value="SHIPPING">SHIPPING</option>
                   <option value="KOMAX">KOMAX</option>
                   <option value="LP">LP</option>
                   <option value="MAGACIN">MAGACIN</option>
                   <option value="SCARP">SCARP</option>
                   <option value="QUALITY">QUALITY</option>
                   <option value="REWORK">REWORK</option>
                   <option value="JIT">JIT</option>
                   <option value="DIY CENTAR">DIY CENTAR</option>
                   <option value="SHIFT LEADER">SHIFT LEADER</option>
                   <option value="PRODUCTION">PRODUCTION</option>
                   <option value="RADIONICA">RADIONICA</option>
                   <option value="OPEN OFFICE">OPEN OFFICE</option>
                   <option value="TRENING CENTAR">TRENING CENTAR</option>
                   <option value="HR">HR</option>
                   <option value="ME">ME</option>
                   <option value="EHS">EHS</option>
                   <option value="FINANSIJE">FINANSIJE</option>
                   <option value="SECURITAS">SECURITAS</option>
                 </select>
              </div>
              <div class="form-group">
                 <label>Lokacija:</label>
                 <select class="form-control" id="sel2" name="location" required>
                   <option value="NS1">NS1</option>
                   <option value="NS2">NS2</option>
                 </select>
               </div>
               <div class="form-group">
                 <label>Vrsta tiketa:</label>
                 <select class="form-control" name="type_tic" id="sel3" required>
                   <option value="INCIDENT">INCIDENT</option>
                   <option value="ZAHTEV">ZAHTEV</option>
                 </select>
               </div>
               <div class="form-group">
                 <label>Tip problema:</label>
                 <select class="form-control" name="type_prob" id="sel4" required>
                   <optgroup label="NALOZI:">
                     <option value="NALOZI: Otvaranje novog naloga za zaposlenog">Otvaranje novog naloga za zaposlenog</option>
                     <option value="NALOZI: Pristup share folderu">Pristup share folderu</option>
                     <option value="NALOZI: Podnosenje zahteva">Podnošenje zahteva</option>
                     <option value="NALOZI: Problem sa nalogom">Problem sa nalogom</option>
                     <option value="NALOZI: Izmena postojeceg naloga">Izmena postojećeg naloga</option>
                   </optgroup>
                   <optgroup label="STAMPACI:">
                     <option value="STAMPACI: Problem sa stampacem">Problem sa štampačem</option>
                     <option value="STAMPACI: Setovanje stampaca">Setovanje štampača</option>
                     <option value="STAMPACI: Zamena tonera">Zamena tonera</option>
                   </optgroup>
                   <optgroup label="OFFICE PAKET:">
                     <option value="OFFICE PAKET: Outlook mail problem">Outlook mail problem</option>
                     <option value="OFFICE PAKET: Excel problem">Excel problem</option>
                     <option value="OFFICE PAKET: Teams problem">Teams problem</option>
                     <option value="OFFICE PAKET: Istekla licenca">Istekla licenca</option>
                     <option value="OFFICE PAKET: Product activation">Product activation</option>
                   </optgroup>
                   <optgroup label="TELEFONI:">
                     <option value="TELEFONI: Problem sa telefonom">Problem sa telefonom</option>
                     <option value="TELEFONI: WiFi problem">WiFi problem</option>
                   </optgroup>
                   <optgroup label="RACUNARI:">
                     <option value="RACUNARI: Pristup VPN">Pristup VPN</option>
                     <option value="RACUNARI: Problem sa konekcijom na mrezu">Problem sa konekcijom na mrezu</option>
                     <option value="RACUNARI: BitLocker problem">BitLocker problem</option>
                     <option value="RACUNARI: Problem sa racunarom">Problem sa računarom</option>
                     <option value="RACUNARI: Problem sa monitorom">Problem sa monitorom</option>
                     <option value="RACUNARI: Zamena HDD">Zamena HDD</option>
                   </optgroup>
                   <optgroup label="APLIKACIJE:">
                     <option value="APLIKACIJE: Instaliranje aplikacije">Instaliranje aplikacije</option>
                     <option value="APLIKACIJE: Ne radi aplikacija">Ne radi aplikacija</option>
                     <option value="APLIKACIJE: Obuka za koriscenje">Obuka za korišćenje</option>
                   </optgroup>
                   <optgroup label="KAMERE:">
                     <option value="KAMERE: Ne radi kamera">Ne radi kamera</option>
                     <option value="KAMERE: Pregled snimka">Pregled snimka</option>
                     <option value="KAMERE: Pristup kamerama">Pristup kamerama</option>
                   </optgroup>
                   </optgroup>
                   <optgroup label="SPICA CHECKERI:">
                     <option value="SPICA CHECKERI: Ne rade checkeri">Ne rade checkeri</option>
                     <option value="SPICA CHECKERI: Odobrenje za pristup">Odobrenje za pristup</option>
                   </optgroup>
                   <option value="Ostalo" selected>Ostalo</option>
                 </select>
               </div>
               <div class="form-group">
                 <label>Opis problema:</label>
                 <textarea name="description" class="form-control" placeholder="Opišite problem.." rows="3"></textarea>
               </div>
             <button type="submit" name="btn_insert" class="btn btn-success btn-main">Pošalji</button>
             <button type="reset" class="btn btn-primary float-right btn-main">Resetuj</button>
         </form>
    </div>
</div>
<!-- COMFIRM FORM BEFORE INSENT IN DB-->
<script src="JS/comfirmBeforeInsertData.js"></script>
<?php
require_once "db_conn.php";
session_start();
error_reporting(0);

if(empty($_SESSION['logged_in']))
{
    header('Location: /ITS/admin_logIn');
    exit;
}

require "scripts/sqlTIC_upiti.php";


function ticList($data){
    $i = 0;
    while($res =  mysqli_fetch_assoc($data)){
       $i++;
       echo "<tr>";
       echo "<th  scope='col' class='text-white'>$i</th>";
       echo "<th scope='col' class='text-white'>".$res['tic_number']."</th>";
       echo "<th scope='col' class='text-white'>".$res['email']."</th>";
       echo "<th scope='col' class='text-white'>".$res['name']."</th>";
       echo "<th scope='col' class='text-white'>".$res['surname']."</th>";
       echo "<th scope='col' class='text-white'>".$res['type_tic']."</th>";
       echo "<th scope='col' class='text-white'>".$res['status']."</th>";
       echo "<th scope='col' class='text-white'>".$res['date_created']."</th>";
       echo "<th scope='col' class='text-white'><a href='admin_oneTic_select?ticID=".$res['tic_number']."'><button class='btn btn-sm btn-primary btn-select btn-main'>Prikaži više</button></a></th>";
       echo "</tr>";
     }
   }

   
   if($_GET['tic'] == 1 OR $_GET['tic'] == 2 OR $_GET['tic'] == 3 OR $_GET['tic'] == 4){
    $kategorija = "Svi tiketi";
   }
   if($_GET['tic'] == 5 OR $_GET['tic'] == 6 OR $_GET['tic'] == 7 OR $_GET['tic'] == 8){
    $kategorija = "NS1";
   }
   if($_GET['tic'] == 9 OR $_GET['tic'] == 10 OR $_GET['tic'] == 11 OR $_GET['tic'] == 12){
    $kategorija = "NS2";
   }
   if($_GET['tic'] == 13 OR $_GET['tic'] == 14 OR $_GET['tic'] == 15 OR $_GET['tic'] == 16){
    $kategorija = "INCIDENTI";
   }
   if($_GET['tic'] == 17 OR $_GET['tic'] == 18 OR $_GET['tic'] == 19 OR $_GET['tic'] == 20){
    $kategorija = "ZAHTEVI";
   }
   if($_GET['tic'] == 21 OR $_GET['tic'] == 22 OR $_GET['tic'] == 23){
    $kategorija = "Moji Tiketi";
   }
?>
<div class="container animate-bottom" id="container">
<button onclick="goBack()" class="btn btn-primary button-back btn-main"><i class="bi bi-arrow-left-square"></i> Nazad</button>
<br><br>

    <div class="card card-admin bg-secondary text-white text-center">
            <h3 class="text-center h3f">TIKETI: <?php echo $_GET['type']. " - " .$kategorija; ?></h3>
            <table class="table table-dark">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col" class="text-primary">ID TIKETA</th>
                  <th scope="col" class="text-primary">Email</th>
                  <th scope="col" class="text-primary">Ime</th>
                  <th scope="col" class="text-primary">Prezime</th>
                  <th scope="col" class="text-primary">TIP</th>
                  <th scope="col" class="text-primary">STATUS</th>
                  <th scope="col" class="text-primary">Datum kreiranja</th>
                  <th scope="col" class="text-primary">Action</th>
                </tr>
              </thead>
              <tbody>
              <?php
              if($_GET['tic'] == 1){
                ticList($result1);
              }
              else if($_GET['tic'] == 2){
                ticList($result2);
              }
              else if($_GET['tic'] == 3){
                ticList($result3);
              }
              else if($_GET['tic'] == 4){
                ticList($result4);
              }
              else if($_GET['tic'] == 5){
                ticList($result5);
              }
              else if($_GET['tic'] == 6){
                ticList($result7);
              }
              else if($_GET['tic'] == 7){
                ticList($result9);
              }
              else if($_GET['tic'] == 8){
                ticList($result11);
              }
              else if($_GET['tic'] == 9){
                ticList($result6);
              }
              else if($_GET['tic'] == 10){
                ticList($result8);
              }
              else if($_GET['tic'] == 11){
                ticList($result10);
              }
              else if($_GET['tic'] == 12){
                ticList($result12);
              }
              else if($_GET['tic'] == 13){
                ticList($result13);
              }
              else if($_GET['tic'] == 14){
                ticList($result15);
              }
              else if($_GET['tic'] == 15){
                ticList($result17);
              }
              else if($_GET['tic'] == 16){
                ticList($result19);
              }
              else if($_GET['tic'] == 17){
                ticList($result14);
              }
              else if($_GET['tic'] == 18){
                ticList($result16);
              }
              else if($_GET['tic'] == 19){
                ticList($result18);
              }
              else if($_GET['tic'] == 20){
                ticList($result20);
              }
              //MY TICKETS
              else if($_GET['tic'] == 21){
                ticList($result_u_o);
              }
              else if($_GET['tic'] == 22){
                ticList($result_u_z);
              }
              else if($_GET['tic'] == 23){
                ticList($result_u_r);
              }
                 
               ?>              
              </tbody>
         </table>
    </div>
</div>
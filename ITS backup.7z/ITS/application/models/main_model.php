<?php 
class main_model extends CI_Model 
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
 //---------------------------------------------------------------------------------------------------------------------------------   
    function get_last_ten_entries()
    {
        $query = $this->db->get('entries', 10);
        return $query->result();
    }
//---------------------------------------------------------------------------------------------------------------------------------

    


}